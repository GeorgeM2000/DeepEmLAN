import sys
reload(sys)
import config
sys.setdefaultencoding( "utf-8" ) 
import numpy as np
from negativeSample import InitNegTable
import random
class dataSet:
	def __init__(self, text_path, graph_path, label_dic):

		text_file, graph_file = self.load(text_path, graph_path)
		self.edges = self.load_edges(graph_file)
		self.label_dic = label_dic
		self.text, self.num_vocab, self.num_nodes = self.load_text(text_file)
		self.negative_table = InitNegTable(self.edges)


	def load(self, text_path, graph_path):

		text_file = open(text_path, 'rb').readlines()
		graph_file = open(graph_path, 'rb').readlines()
		return text_file, graph_file

	def load_edges(self, graph_file):
		edges = []
		for i in graph_file:
			edges.append(map(int, i.split()))
		return edges

	def load_text(self, text_file):

		text_one = [0]*config.MAX_LEN
		text = []
		for te in text_file:
			i = 0
			j = 0
			tte = te.split()[1:]
			for t in tte:
				if t == '1.0' or t == '1' or t == '1.':
					text_one[j] = i+1
					j = j+1
				i = i+1
			text.append(text_one)
			text_one = [0]*config.MAX_LEN
		text = np.array(text)
		num_vocab = len(text_file[0].split())+1
		self.num_nodes = len(text)
		return text, num_vocab, self.num_nodes
	
	def negative_sample(self, edges):
		node1, node2 = zip(*edges)[0:2]
		neg_sample_edges = []
		func = lambda: self.negative_table[random.randint(0, config.neg_table_size-1)]
		for i in range(len(edges)):
			neg_node = func()
			while self.label_dic[str(node1[i])] == self.label_dic[str(neg_node)] or self.label_dic[str(node2[i])] == \
					self.label_dic[str(neg_node)]:
				neg_node = func()
			neg_sample_edges.append(neg_node)

		return neg_sample_edges

	def generate_batches(self, mode=None):
		r_one_hot = np.zeros(config.tag_size, dtype=float)
		br_one_hot = np.ones(config.tag_size, dtype=float)
		num_batch = len(self.edges)/config.batch_size
		edge_l = self.edges
		for i in range(0, config.edge_num):
			r_one_hot[int(self.label_dic[str(edge_l[i][0])])] = 1.0
			r_one_hot[int(self.label_dic[str(edge_l[i][1])])] = 1.0
			br_one_hot[int(self.label_dic[str(edge_l[i][0])])] = config.Beta
			br_one_hot[int(self.label_dic[str(edge_l[i][1])])] = config.Beta
			edge_l[i].append(r_one_hot)
			edge_l[i].append(br_one_hot)
			r_one_hot = np.zeros(config.tag_size, dtype=float)
			br_one_hot = np.ones(config.tag_size, dtype=float)
		if mode == 'add':
			num_batch += 1
			edge_l.extend(edge_l[:(config.batch_size-len(self.edges)//config.batch_size)])
		if mode != 'add':
			random.shuffle(edge_l)

		sample_edges = edge_l[:num_batch*config.batch_size]
		sample_neg = self.negative_sample(sample_edges)



		shuffle_edges = []
		shuffle_relation = []
		shuffle_brelation = []
		# shuffle_edgetags = []
		for edge in sample_edges:
			shuffle_edges.append([edge[0], edge[1]])
			shuffle_relation.append(edge[2])
			shuffle_brelation.append(edge[3])
		batches_edges = []
		batches_re = []
		batches_neg = []
		batches_br = []
		for j in range(num_batch):
			batches_edges.append(shuffle_edges[j * config.batch_size:(j + 1) * config.batch_size])
			batches_re.append(np.array(shuffle_relation[j * config.batch_size:(j + 1) * config.batch_size]))
			batches_neg.append(sample_neg[j * config.batch_size:(j + 1) * config.batch_size])
			batches_br.append(np.array(shuffle_brelation[j * config.batch_size:(j + 1) * config.batch_size]))

		return batches_edges, batches_re, batches_neg, batches_br
