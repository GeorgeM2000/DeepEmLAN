import numpy as np
import tensorflow as tf
import config
import random
class Model:
    def __init__(self, data, order):
        self.cur_epoch = 0
        self.vocab_size = data.num_vocab
        self.num_nodes = data.num_nodes
        self.order = order
        self.data = data
        self.sess = tf.Session()
        self.n_hidden_1 = 64
        self.n_hidden_2 = 32
        self.output_size = config.tag_size
        cur_seed = random.getrandbits(32)
        initializer = tf.contrib.layers.xavier_initializer(uniform=False, seed=cur_seed)
        with tf.variable_scope("model", reuse=None, initializer=initializer):
            self.build_graph()
        self.sess.run(tf.global_variables_initializer())

    def build_graph(self):
            # '''hyperparameter'''
        with tf.name_scope('read_inputs') as scope:
            self.Text_a = tf.placeholder(tf.int32, [config.batch_size, config.MAX_LEN], name='Ta' + str(self.order))
            self.Text_b = tf.placeholder(tf.int32, [config.batch_size, config.MAX_LEN], name='Tb' + str(self.order))
            self.Text_pos = tf.placeholder(tf.int32, [config.batch_size, config.MAX_LEN], name='Tpos'+ str(self.order))
            self.Text_neg = tf.placeholder(tf.int32, [config.batch_size, config.MAX_LEN], name='Tneg'+ str(self.order))
            self.Node_a = tf.placeholder(tf.int32, [config.batch_size], name='n1' + str(self.order))
            self.Node_b = tf.placeholder(tf.int32, [config.batch_size], name='n2' + str(self.order))
            self.Node_pa = tf.placeholder(tf.int32, [config.batch_size], name='n4' + str(self.order))
            self.Node_na = tf.placeholder(tf.int32, [config.batch_size], name='n5' + str(self.order))
            self.relation = tf.placeholder(tf.float32, [config.batch_size, config.tag_size], name='r' + str(self.order))
            self.brelation = tf.placeholder(tf.float32, [config.batch_size, config.tag_size], name='br' + str(self.order))
        with tf.name_scope('initialize_para') as scope:
            self.weights = {
                'encoder_h1'+ str(self.order): tf.Variable(tf.random_normal([int(config.embed_size / 2), self.n_hidden_1])),
                'encoder_h2'+ str(self.order): tf.Variable(tf.random_normal([self.n_hidden_1, self.n_hidden_2])),
                'encoder_h3'+ str(self.order): tf.Variable(tf.random_normal([self.n_hidden_2, self.output_size]))
            }
            cur_seed = random.getrandbits(32)
            self.biases = {
                'encoder_b1'+ str(self.order): tf.Variable(tf.random_normal([self.n_hidden_1])),
                'encoder_b2'+ str(self.order): tf.Variable(tf.random_normal([self.n_hidden_2])),
                'encoder_b3'+ str(self.order): tf.Variable(tf.random_normal([self.output_size]))
            }

        with tf.name_scope('initialize_embedding') as scope:
            cur_seed = random.getrandbits(32)
            self.context_embed = tf.get_variable(name="context_embeddings"+ str(self.order),
                                                 shape=[self.num_nodes, int(config.embed_size / 2)],
                                                 initializer=tf.contrib.layers.xavier_initializer(uniform=False,
                                                                                                  seed=cur_seed))
            self.text_embed = tf.get_variable(name="text_embeddings"+ str(self.order),
                                              shape=[self.vocab_size, config.embed_size / 2],
                                              initializer=tf.contrib.layers.xavier_initializer(uniform=False,
                                                                                               seed=cur_seed))

            self.node_embed = tf.get_variable(name="embeddings" + str(self.order),
                                              shape=[self.num_nodes, int(config.embed_size / 2)],
                                              initializer=tf.contrib.layers.xavier_initializer(uniform=False,
                                                                                               seed=cur_seed))

        with tf.name_scope('lookup_embeddings') as scope:
            self.TA = tf.nn.embedding_lookup(self.text_embed, self.Text_a)
            self.T_A = tf.expand_dims(self.TA, -1)

            self.TB = tf.nn.embedding_lookup(self.text_embed, self.Text_b)
            self.T_B = tf.expand_dims(self.TB, -1)

            self.Tpos = tf.nn.embedding_lookup(self.text_embed, self.Text_pos)
            self.T_POS = tf.expand_dims(self.Tpos, -1)

            self.TNEG = tf.nn.embedding_lookup(self.text_embed, self.Text_neg)
            self.T_NEG = tf.expand_dims(self.TNEG, -1)

            self.N_A = tf.nn.l2_normalize(tf.nn.embedding_lookup(self.node_embed, self.Node_a), 1)
            self.N_B = tf.nn.l2_normalize(tf.nn.embedding_lookup(self.node_embed, self.Node_b), 1)
            self.N_POS = tf.nn.embedding_lookup(self.node_embed, self.Node_pa)
            self.N_NEG = tf.nn.embedding_lookup(self.node_embed, self.Node_na)
            self.N_NEG_list = tf.split(self.N_NEG, config.negative_ratio, 1)

            self.pos_nb_context = tf.nn.l2_normalize(
                tf.nn.embedding_lookup(self.context_embed, tf.cast(self.Node_b, tf.int32)), 1)
            self.pos_ab = tf.nn.l2_normalize(
                tf.nn.embedding_lookup(self.node_embed, tf.cast(self.Node_pa, tf.int32)), 1)
            self.neg_ab = tf.nn.l2_normalize(
                tf.nn.embedding_lookup(self.node_embed, tf.cast(self.Node_na, tf.int32)), 1)
            self.neg_ab_context = tf.nn.l2_normalize(
                tf.nn.embedding_lookup(self.context_embed, tf.cast(self.Node_na, tf.int32)), 1)
        self.R_AB, self.l_predict = self.conv()
        self.loss = self.compute_loss(self.order)
        optimizer = tf.train.AdamOptimizer(config.lr)
        self.train_op = optimizer.minimize(self.loss)

    def train_one_epoch(self):
        loss_epoch = 0
        batches_edges, batches_re, batches_neg, batches_br = self.data.generate_batches()
        num_batch = len(batches_edges)
        for i in range(num_batch):
            node1, node2 = zip(*batches_edges[i])
            node_list4 = batches_neg[i]
            batch_r = batches_re[i]
            batch_br = batches_br[i]
            node_list3 = node2
            node1, node2, node_list3, node_list4 = np.array(node1), np.array(node2), \
                                                          np.array(node_list3), np.array(node_list4)
            node_list3 = np.transpose(node_list3)
            text1, text2 = self.data.text[node1], self.data.text[node2]
            text_pos = []
            text_neg = []
            for npp in node_list3:
                text_pos.append(self.data.text[npp])
            for nn in node_list4:
                text_neg.append(self.data.text[nn])
            feed_dict = {
                self.Text_a: text1,
                self.Text_b: text2,
                self.Text_pos: text_pos,
                self.Text_neg: text_neg,
                self.Node_a: node1,
                self.Node_b: node2,
                self.Node_pa: node_list3,
                self.Node_na: node_list4,
                self.relation: batch_r,
                self.brelation: batch_br

            }

            # run the graph
            _, loss_batch = self.sess.run([self.train_op, self.loss], feed_dict=feed_dict)
            # print loss_batch
            loss_epoch += loss_batch
        print str('order' + str(self.order) + ':'), self.cur_epoch, ' loss: ', loss_epoch
        self.cur_epoch += 1

    def encoder(self, x):
        layer_1 = tf.nn.tanh(tf.add(tf.matmul(tf.reshape(x,[config.batch_size, int(config.embed_size/2)]), self.weights['encoder_h1'+ str(self.order)]),
                                       self.biases['encoder_b1'+ str(self.order)]))
        layer_2 = tf.nn.tanh(tf.add(tf.matmul(layer_1, self.weights['encoder_h2'+ str(self.order)]),
                                       self.biases['encoder_b2'+ str(self.order)]))
        layer_3 = tf.reshape(tf.nn.tanh(tf.add(tf.matmul(layer_2, self.weights['encoder_h3'+ str(self.order)]),
                                       self.biases['encoder_b3'+ str(self.order)])),[config.batch_size,1,self.output_size])
        return layer_3

    def conv(self):

        TA_norm = tf.sqrt(tf.reduce_sum(self.TA*self.TA, 1))
        TB_norm = tf.sqrt(tf.reduce_sum(self.TB*self.TB, 1))
        TA_TB = tf.reduce_sum(self.TA*self.TB, 1)
        # self.TN = tf.reshape(tf.split(self.TNEG, config.negative_ratio, 1)[0],
        #            [config.batch_size, int(config.embed_size / 2), int(config.embed_size / 2)])
        cosinAB = tf.div(TA_TB, TA_norm*TB_norm+1e-8)

        cosin1 = tf.expand_dims(cosinAB, -1)


        self.u_A = tf.reshape(tf.matmul(self.TA, cosin1), [config.batch_size, int(config.embed_size / 2)])
        self.u_B = tf.reshape(tf.matmul(self.TB, cosin1), [config.batch_size, int(config.embed_size / 2)])
        self.u_P = tf.reshape(tf.matmul(self.Tpos, cosin1), [config.batch_size, int(config.embed_size / 2)])
        self.u_N = tf.reshape(tf.matmul(self.TNEG, cosin1),
                              [config.batch_size, int(config.embed_size / 2)])


        R_AB = self.u_A + self.u_B
        self.R_AB = tf.reshape(R_AB, [config.batch_size, int(config.embed_size / 2)])

        l_predict = self.encoder(tf.reshape(self.R_AB, [config.batch_size, 1, int(config.embed_size / 2)]))
        return R_AB, l_predict
    def compute_loss(self,order):

        rho1 = 0.3
        rho2 = 0.1
        rho3 = 0.3
        p1 = tf.reduce_sum(tf.multiply(self.u_A, self.u_B), 1)
        p1 = tf.log(tf.sigmoid(p1) + 0.001)
        p2 = tf.reduce_sum(tf.multiply(self.N_A, self.N_B), 1)
        p2 = tf.log(tf.sigmoid(p2) + 0.001)

        p3 = tf.reduce_sum(tf.multiply(self.N_A, self.u_A), 1)
        p3 = tf.log(tf.sigmoid(p3) + 0.001)
        p4 = tf.reduce_sum(tf.multiply(self.N_B, self.u_B), 1)
        p4 = tf.log(tf.sigmoid(p4) + 0.001)


        for i in range(0, 1):
        # for i in range(0, config.negative_ratio):
            u_P1 = tf.reshape(tf.split(self.u_P, config.negative_ratio, 1)[i], [config.batch_size, int(config.embed_size / 2)])
            u_N1 = tf.reshape(tf.split(self.u_N, config.negative_ratio, 1)[i],
                              [config.batch_size, int(config.embed_size / 2)])
            p5 = tf.reduce_sum(tf.multiply(self.u_A, u_P1), 1)
            p5 = tf.log(tf.sigmoid(p5) + 0.001)
            p6 = tf.reduce_sum(tf.multiply(self.u_B, u_P1), 1)
            p6 = tf.log(tf.sigmoid(p6) + 0.001)
            p7 = tf.reduce_sum(tf.multiply(self.u_A, u_N1), 1)
            p7 = tf.log(tf.sigmoid(-p7) + 0.001)
            p8 = tf.reduce_sum(tf.multiply(self.u_B, u_N1), 1)
            p8 = tf.log(tf.sigmoid(-p8) + 0.001)
            p9 = tf.reduce_sum(tf.multiply(self.N_A, self.N_NEG), 1)
            p9 = tf.log(tf.sigmoid(-p9) + 0.001)
            p10 = tf.reduce_sum(tf.multiply(self.N_B, self.N_NEG), 1)
            p10 = tf.log(tf.sigmoid(-p10) + 0.001)

        p11 = tf.reduce_sum(tf.multiply(self.l_predict, self.relation))
        p11 = tf.log(tf.sigmoid(p11) + 0.001)

        p_all = config.rho1*(p1 + p2 + p5 + p6 + p7 + p8 + p9 + p10) + config.rho2*(p3 + p4) + config.rho3 * p11

        temp_loss = -tf.reduce_sum(p_all+p11)
        self.sample_sum1 = tf.reduce_sum(tf.exp(tf.multiply(self.pos_ab, self.neg_ab)),
                                         axis=1)
        self.first_loss = tf.reduce_mean(-tf.reduce_sum(tf.multiply(self.N_A, self.N_B), axis=1) +
                                         tf.log(self.sample_sum1))
        self.sample_sum2 = tf.reduce_sum(
            tf.exp(tf.multiply(self.pos_ab, self.neg_ab_context)), axis=1)
        self.second_loss = tf.reduce_mean(-tf.reduce_sum(tf.multiply(self.N_A, self.pos_nb_context), axis=1) +
                                          tf.log(self.sample_sum2))
        loss = temp_loss + self.first_loss + self.second_loss


        return loss


    def get_embedding(self):
        vectors = {}
        zero_list = []
        for i in range(0, int(config.embed_size)):
            zero_list.append(0)
        zero_list = np.array(zero_list)
        embed = [[] for _ in range(self.data.num_nodes)]

        batches_edges, batches_re, batches_neg, batches_br = self.data.generate_batches(mode='add')
        num_batch = len(batches_edges)
        for i in range(num_batch):
            node1, node2 = zip(*batches_edges[i])
            node_list4 = batches_neg[i]
            batch_r = batches_re[i]
            batch_br = batches_br[i]

            node_list3 = node2
            node1, node2, node_list3, node_list4 = np.array(node1), np.array(node2), \
                                                                 np.array(node_list3), np.array(
                node_list4)
            node_list3 = np.transpose(node_list3)
            text1, text2 = self.data.text[node1], self.data.text[node2]
            text_pos = []
            text_neg = []
            for npp in node_list3:
                text_pos.append(self.data.text[npp])
            for nn in node_list4:
                text_neg.append(self.data.text[nn])


            feed_dict = {
                self.Text_a: text1,
                self.Text_b: text2,
                self.Text_pos: text_pos,
                self.Text_neg: text_neg,
                self.Node_a: node1,
                self.Node_b: node2,
                self.Node_pa: node_list3,
                self.Node_na: node_list4,
                self.relation: batch_r,
                self.brelation: batch_br

            }
            uA, uB, rAB, NA, NB = self.sess.run([self.u_A, self.u_B, self.R_AB, self.N_A, self.N_B], feed_dict=feed_dict)

            for i in range(config.batch_size):
                embed[node1[i]].append(list(NA[i])+list(rAB[i]))  #
                embed[node2[i]].append(list(NB[i])+list(rAB[i]))  #

        for i in range(self.data.num_nodes):
            if embed[i]:
                tmp=np.sum(embed[i],axis=0)/len(embed[i])
                vectors[i]=tmp
                # file.write(' '.join(map(str,tmp))+'\n')
            else:
                vectors[i]=zero_list
        return vectors