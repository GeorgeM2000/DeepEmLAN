import numpy as np
from DataSet import dataSet
import config
import deepemlan
from sklearn.linear_model import LogisticRegression
from classify import Classifier




def get_key(dict,value):
    return [k for k, v in dict.items() if v == value]

if __name__ == '__main__':
	#load data
	save_f = '/home/zhouhui/PycharmProjects/untitled/DeepEmLAN-master/data/cora/clf_result.txt'
	graph_path = r'/home/zhouhui/PycharmProjects/untitled/DeepEmLAN-master/data/cora/graph.txt'
	node_tag = r'/home/zhouhui/PycharmProjects/untitled/DeepEmLAN-master/data/cora/group.txt'
	text_path = r'/home/zhouhui/PycharmProjects/untitled/DeepEmLAN-master/data/cora/feature.txt'

	clf_ratio = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9]
	clf_num = 5
	train_classifier = True
	label_dic = {}
	f4 = open(node_tag, 'r')
	labels = f4.readlines()
	f4.close()
	for la in labels:
		label_dic[la.split()[0]] = la.split()[1:][0]

	data = dataSet(text_path, graph_path, label_dic)

	# start session
	zero_list = []
	f1 = open(graph_path, 'r')
	eedges = f1.readlines()
	f1.close()
	edge_list = []
	nodes = []
	for ee in eedges:
		edge_list.append(list(ee.split()))
	for ll in edge_list:
		for ed in ll:
			if ed not in nodes:
				nodes.append(ed)
			else:
				continue

	for i in range(0, int(config.embed_size*2)):
		zero_list.append(0)
	model1 = deepemlan.Model(data, 1)
	for i in range(config.num_epoch):
		model1.train_one_epoch()
	print 'get model vector'
	vectors = model1.get_embedding()

	node_nei_list = {}
	one_node_edges = []
	for ii in nodes:
		for ed in edge_list:
			if ii in ed:
				if label_dic[ii] == label_dic[ed[0]] and ii not in one_node_edges:
					one_node_edges.append(ed[0])
				if label_dic[ii] == label_dic[ed[1]] and ii not in one_node_edges:
					one_node_edges.append(ed[1])
			else:
				pass
		node_nei_list[ii] = one_node_edges
		one_node_edges = []


	new_vector = {}
	one_node_new_vec = []
	for ve in vectors.keys():
		for nnl in node_nei_list[str(ve)]:
			one_node_new_vec.append(vectors[int(nnl)])
		one_node_new_vec = np.array(one_node_new_vec).sum(axis=0)/len(node_nei_list[str(ve)])
		new_vector[ve] = one_node_new_vec
		one_node_new_vec = []

	if train_classifier:
		clf_test_len = len(nodes)
		print('train classifier start!')
		X = []
		Y = []
		f2 = open(node_tag, 'r')
		tags = f2.readlines()
		f2.close()
		for jk in range(0, clf_test_len):
			if str(jk) in nodes:
				tag_list = tags[jk].strip().split()
				# Y.append([(int)(i) for i in tags])
				lli = [str(i) for i in tag_list]
				if len(lli) != 0:
					if np.array(new_vector[jk]).any() != np.array(zero_list).any():
						X.append(jk)
						Y.append(lli[1:][0])
		mi = {}
		ma = {}
		li1 = []
		li2 = []
		f5 = open(save_f, 'w')


		for i in range(0, len(clf_ratio)):
			for j in range(0, clf_num):
				clf = Classifier(vectors=new_vector, clf=LogisticRegression())
				result = clf.split_train_evaluate(X, Y, clf_ratio[i])
				li1.append(result['micro'])
				li2.append(result['macro'])
			mi[str(str(clf_ratio[i]) + '-micro')] = sum(li1) / clf_num
			ma[str(str(clf_ratio[i]) + '-macro')] = sum(li2) / clf_num
			print mi, ma
			f5.writelines(str(str(mi)+str(ma)))
			f5.write('\n')
			mi = {}
			ma = {}
			li1 = []
			li2 = []
		f5.close()